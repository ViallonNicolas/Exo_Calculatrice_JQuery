/*afficher les chiffres cliqués*/
function AjouterChiffre(id)
{
	var btn = document.getElementById(id).innerHTML;
	document.getElementById("result").innerHTML = document.getElementById("result").innerHTML + btn;
}

/*afficher les opérateurs cliqués, un seul opérateur possible à la fois*/
function AjouterOPplus(id)
{
	var op = document.getElementById(id).innerHTML;
	var chaine = document.getElementById("result").innerHTML;
	if (chaine.includes("+") == false) 
		{ if (chaine.includes("-") == false) 
			{ if (chaine.includes("X") == false) 
				{ if (chaine.includes("/") == false) 
					{ document.getElementById("result").innerHTML = document.getElementById("result").innerHTML + op;
					}
				}
			}
		}
}

function AjouterOPmoins(id)
{
	var op = document.getElementById(id).innerHTML;
	var chaine = document.getElementById("result").innerHTML;
	if (chaine.includes("+") == false) 
		{ if (chaine.includes("-") == false) 
			{ if (chaine.includes("X") == false) 
				{ if (chaine.includes("/") == false) 
					{ document.getElementById("result").innerHTML = document.getElementById("result").innerHTML + op;
					}
				}
			}
		}
}

function AjouterOPfois(id)
{
	var op = document.getElementById(id).innerHTML;
	var chaine = document.getElementById("result").innerHTML;
	if (chaine.includes("+") == false) 
		{ if (chaine.includes("-") == false) 
			{ if (chaine.includes("X") == false) 
				{ if (chaine.includes("/") == false) 
					{ document.getElementById("result").innerHTML = document.getElementById("result").innerHTML + op;
					}
				}
			}
		}
}

function AjouterOPdiv(id)
{
	var op = document.getElementById(id).innerHTML;
	var chaine = document.getElementById("result").innerHTML;
	if (chaine.includes("+") == false) 
		{ if (chaine.includes("-") == false) 
			{ if (chaine.includes("X") == false) 
				{ if (chaine.includes("/") == false) 
					{ document.getElementById("result").innerHTML = document.getElementById("result").innerHTML + op;
					}
				}
			}
		}
}


/*effacer tout le résultat*/
function EffacerResult(id)
{
	document.getElementById("result").innerHTML = "";
}

/*effacer le dernier chiffre ou opérateur*/
function EffacerFleche(id)
{
	var chaine = document.getElementById('result').innerHTML;
	var newchaine = chaine.slice(0,-1);
	document.getElementById('result').innerHTML = newchaine;
}




/*fonctions de calcul de chaque type d'operation*/
function Add()
{
	var chaine = document.getElementById('result').innerHTML;
	var n = chaine.indexOf("+");
	var n1 = chaine.substring(0,n);
	var n2 = chaine.substring(n+1);
	var res = parseFloat(n1) + parseFloat(n2);
	document.getElementById('result').innerHTML = res;

}
function Sous()
{
	var chaine = document.getElementById('result').innerHTML;
	var n = chaine.indexOf("-");
	var n1 = chaine.substring(0,n);
	var n2 = chaine.substring(n+1);
	var res = parseFloat(n1) - parseFloat(n2);
	document.getElementById('result').innerHTML = res;

}

function Mult()
{
	var chaine = document.getElementById('result').innerHTML;
	var n = chaine.indexOf("X");
	var n1 = chaine.substring(0,n);
	var n2 = chaine.substring(n+1);
	var res = parseFloat(n1) * parseFloat(n2);
	document.getElementById('result').innerHTML = res;

}

function Div()
{
	var chaine = document.getElementById('result').innerHTML;
	var n = chaine.indexOf("/");
	var n1 = chaine.substring(0,n+1);
	var n2 = chaine.substring(n+1);
	var res = parseFloat(n1) / parseFloat(n2);
	document.getElementById('result').innerHTML = res;

}



/*afficher le resultat des valeurs cliquées*/
function Calcul()
{	
	var chaine = document.getElementById('result').innerHTML;
	if (chaine.includes("+") == true) {
	Add();
	}
	if (chaine.includes("-") == true) {
	Sous();
	}
	if (chaine.includes("X") == true) {
	Mult();
	}
	if (chaine.includes("/") == true) {
	Div();
	}
}



/*effacer les derniers chiffres apres l'opérateur*/
function EffacerC()
{	
	var chaine = document.getElementById('result').innerHTML;
	if (chaine.includes("+") == true) {
		var n = chaine.indexOf("+");
		var newchaine = chaine.substring(0,n+1);
		document.getElementById('result').innerHTML = newchaine;
	}
	if (chaine.includes("-") == true) {
		var n = chaine.indexOf("-");
		var newchaine = chaine.substring(0,n+1);
		document.getElementById('result').innerHTML = newchaine;
	}
	if (chaine.includes("X") == true) {
		var n = chaine.indexOf("X");
		var newchaine = chaine.substring(0,n+1);
		document.getElementById('result').innerHTML = newchaine;
	}
	if (chaine.includes("/") == true) {
		var n = chaine.indexOf("/");
		var newchaine = chaine.substring(0,n+1);
		document.getElementById('result').innerHTML = newchaine;
	}
	
}


/*ajouter une virgule*/
function AjouterVirgule(id)
{
	var virgule = document.getElementById(id).innerHTML;
	var chaine = document.getElementById('result').innerHTML;
	if (chaine.includes(",") == false) {
		document.getElementById('result').innerHTML = document.getElementById('result').innerHTML + virgule;
	}
	
	
}
